/*
 * ProgramMPI.h
 *
 *  Created on: 11 janv. 2021
 *      Author: laloukil
 */

#ifndef PROGRAM_H_
#define PROGRAM_H_

double launch(int);

#endif /* PROGRAM_H_ */
