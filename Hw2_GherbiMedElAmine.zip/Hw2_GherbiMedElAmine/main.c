#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <mpi.h>

#include "initMatrix.h"
#include "displayMatrix.h"
#include "ProgramMPI.h"

// Variables globales
int n;       // Taille de la matrice
int **A;     // Éléments de la matrice A
int **B;     // Éléments de la matrice B
int **C;     // Éléments de la matrice C
int rank, size; // Rang et taille du communicateur MPI

int main(int argc, char **argv)
{
  MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);

  int i;
  int numProcess = 2;

  if (rank == 0)
  {
    if (argc < 3)
    {
      printf("Usage: ./GHERBI [num threads]\n");
      printf("<size>: Taille de la matrice\n");
    }

    printf("Mode : Multiplication en deux étapes par les processus P1 et P2\n");
    n = atoi(argv[1]);

    if (n <= 1)
    {
      printf("Attention : la taille de la matrice doit être > 2\n");
      exit(1);
    }

    printf("Taille de la matrice : %d\n", n);
    srand(time(NULL));

    // Allocation et initialisation de la matrice A
    A = (int **)malloc(n * sizeof(int *));
    for (i = 0; i < n; i++)
      A[i] = (int *)malloc(n * sizeof(int));
    generateRandomMatrix(A, n, 0, 99);
    printf("A\n");
    printMatrix(A, n);

    // Allocation et initialisation de la matrice B
    B = (int **)malloc(n * sizeof(int *));
    for (i = 0; i < n; i++)
      B[i] = (int *)malloc(n * sizeof(int));
    generateRandomMatrix(B, n, 0, 99);
    printf("B\n");
    printMatrix(B, n);

   
  }

  // Diffusion de la taille de la matrice à tous les processus MPI
  MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);

  // Allocation et initialisation de la matrice C
  C = (int **)malloc(n * sizeof(int *));
  for (i = 0; i < n; i++)
    C[i] = (int *)malloc(n * sizeof(int));

  double tmp;

  // Génération d'une matrice C aléatoire
  generateRandomMatrix(C, n, 0, 0);

  // Exécution de la multiplication en deux étapes avec 'numProcess' processus
  tmp = launch(numProcess);

    printf("Temps total P: %f\n", tmp);

  // Génération d'une nouvelle matrice C aléatoire
  generateRandomMatrix(C, n, 0, 0);

  // Exécution de la multiplication en une étape avec un seul processus
  tmp = launch(1);

  if (rank == 0)
  {
    

    // Affichage des matrices   C
    printf("C \n");
    printMatrix(C, n);
   
    
  }
  
  // Libération de la mémoire allouée pour les matrices
  for (i = 0; i < n; ++i)
  {
    if (rank == 0)
    {
      free(A[i]);
      free(B[i]);
 
    }
    free(C[i]);
  }
  if (rank == 0)
  {
    free(A);
    free(B);
   
  }
  free(C);

  // Finalisation de l'environnement MPI
  MPI_Finalize();
  return 0;
}

