/*
 * init-matrix.h
 *
 *  Created on: 5 janv. 2021
 *      Author: laloukil
 */

#ifndef INITMATRIX_H_
#define INITMATRIX_H_

void generateRandomMatrix (int** matrix, int dim, int lowerValue, int upperValue);

#endif /* INITMATRIX_H_ */
