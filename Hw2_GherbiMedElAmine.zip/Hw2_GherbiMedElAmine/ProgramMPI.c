/*
 * multiThreadedProgramExample.c
 *
 *  Created on: 11 janv. 2021
 *      Author: laloukil
 */

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <mpi.h>

#include "ProgramMPI.h"

// Structure pour représenter une matrice
struct Matrix
{
    int index;        // Indice de la ligne ou de la colonne
    int *vector;      // Vecteur représentant la ligne ou la colonne
};

// Déclaration des matrices A, B, C et des variables n, rank, size
extern int **A; // Éléments de la matrice A
extern int **B; // Éléments de la matrice B
extern int **C; // Éléments de la matrice C
extern int n;   // Dimension de la matrice
extern int rank; // Rang du processus MPI
extern int size; // Nombre total de processus MPI

// Fonction pour calculer la transposée d'une matrice
int **transposeMatrix(int **matrix, int n)
{
    int **transposedMatrix = (int **)malloc(n * sizeof(int *));
    for (int i = 0; i < n; ++i)
        transposedMatrix[i] = (int *)malloc(n * sizeof(int));

    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < n; ++j)
        {
            transposedMatrix[j][i] = matrix[i][j];
        }
    }

    return transposedMatrix;
}

// Fonction principale pour effectuer la multiplication de matrices
double launch(int N)
{
    MPI_Barrier(MPI_COMM_WORLD);
    double start_time = MPI_Wtime();

    if (rank < 2)
    {
        MPI_Request request;
        int sizePerProcess = n / 2, remainingSize = n % 2, taille;
        int CountA = sizePerProcess + (rank < remainingSize ? 1 : 0);
        int CountB = CountA;

        // Envoi des lignes de la matrice A au processus 0
        if (rank == 0)
        {
            for (int i = 0; i < CountA; i++)
            {
                int tempValue = i;
                MPI_Send(&tempValue, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
                MPI_Isend(A[i], n, MPI_INT, 0, 0, MPI_COMM_WORLD, &request);
            }
            taille = CountA;
            for (int i = 0; i < sizePerProcess + (1 < remainingSize ? 1 : 0); i++)
            {
                int tempValue = taille + i;
                MPI_Send(&tempValue, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
                MPI_Isend(A[taille + i], n, MPI_INT, 1, 0, MPI_COMM_WORLD, &request);
            }
        }

        // Réception des lignes de la matrice A
        struct Matrix *MatrixA = (struct Matrix *)malloc(CountA * sizeof(struct Matrix));
        for (int i = 0; i < CountA; i++)
        {
            MatrixA[i].vector = (int *)malloc(n * sizeof(int));
            MPI_Recv(&MatrixA[i].index, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            MPI_Recv(MatrixA[i].vector, n, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }

        // Envoi des colonnes transposées de la matrice B au processus 0
        if (rank == 0)
        {
            int **BTranspose = transposeMatrix(B, n);

            for (int i = 0; i < CountB; i++)
            {
                int tempValue = i;
                MPI_Send(&tempValue, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
                MPI_Isend(BTranspose[i], n, MPI_INT, 0, 0, MPI_COMM_WORLD, &request);
            }
            taille = CountB;
            for (int i = 0; i < sizePerProcess + (1 < remainingSize ? 1 : 0); i++)
            {
                int tempValue = taille + i;
                MPI_Send(&tempValue, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
                MPI_Isend(BTranspose[taille + i], n, MPI_INT, 1, 0, MPI_COMM_WORLD, &request);
            }
        }

        // Réception des colonnes transposées de la matrice B
        struct Matrix *MatrixB = (struct Matrix *)malloc(CountB * sizeof(struct Matrix));
        for (int i = 0; i < CountB; i++)
        {
            MatrixB[i].vector = (int *)malloc(n * sizeof(int));
            MPI_Recv(&MatrixB[i].index, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            MPI_Recv(MatrixB[i].vector, n, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }

        // Calcul de la multiplication des matrices locales
        for (int i = 0; i < CountB; i++)
        {
            for (int j = 0; j < CountA; j++)
            {
                int result = 0;
                for (int k = 0; k < n; k++)
                {
                    result += MatrixA[j].vector[k] * MatrixB[i].vector[k];
                }
                C[MatrixA[j].index][MatrixB[i].index] = result;
            }
        }

        // Envoi des résultats partiels au processus 1
        int Count = CountA;
        MPI_Send(&Count, 1, MPI_INT, rank == 0 ? 1 : 0, 0, MPI_COMM_WORLD);
        for (int i = 0; i < CountA; i++)
        {
            int index = MatrixA[i].index;
            int *vector = MatrixB[i].vector;
            MPI_Send(&index, 1, MPI_INT, rank == 0 ? 1 : 0, 0, MPI_COMM_WORLD);
            MPI_Isend(vector, n, MPI_INT, rank == 0 ? 1 : 0, 0, MPI_COMM_WORLD, &request);
        }

        // Réception des résultats partiels du processus 1
        MPI_Recv(&CountA, 1, MPI_INT, rank == 0 ? 1 : 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        free(MatrixA);
        MatrixA = (struct Matrix *)malloc(CountA * sizeof(struct Matrix));
        for (int i = 0; i < CountA; i++)
        {
            MatrixA[i].vector = (int *)malloc(n * sizeof(int));
            MPI_Recv(&MatrixA[i].index, 1, MPI_INT, rank == 0 ? 1 : 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            MPI_Recv(MatrixA[i].vector, n, MPI_INT, rank == 0 ? 1 : 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }

        // Calcul de la deuxième partie de la multiplication des matrices locales
        for (int i = 0; i < CountB; i++)
        {
            for (int j = 0; j < CountA; j++)
            {
                int result = 0;
                for (int k = 0; k < n; k++)
                {
                    result += MatrixA[j].vector[k] * MatrixB[i].vector[k];
                }
                C[MatrixA[j].index][MatrixB[i].index] = result;
            }
        }

        // Transposition de la matrice C
        C = transposeMatrix(C, n);

        // Envoi des lignes de la matrice C au processus 0
        if (rank == 1)
        {
            taille = sizePerProcess + (0 < remainingSize ? 1 : 0);
            for (int i = taille; i < taille + CountB; i++)
            {
                MPI_Isend(C[i], n, MPI_INT, 0, 0, MPI_COMM_WORLD, &request);
            }
        }

        // Réception des lignes de la matrice C par le processus 0
        if (rank == 0)
        {
            taille = sizePerProcess + (0 < remainingSize ? 1 : 0);
            for (int i = taille; i < taille + sizePerProcess + (1 < remainingSize ? 1 : 0); i++)
            {
                MPI_Recv(C[i], n, MPI_INT, 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            }
        }

        // Rétablir la transposition de la matrice C
        C = transposeMatrix(C, n);
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double end_time = MPI_Wtime();

    return end_time - start_time;
}

