/*
 * displayMatrix.h
 *
 *  Created on: 5 janv. 2021
 *      Author: laloukil
 */

#ifndef DISPLAYMATRIX_H_
#define DISPLAYMATRIX_H_

void printMatrix(int** matrix, int n);

#endif /* DISPLAYMATRIX_H_ */
